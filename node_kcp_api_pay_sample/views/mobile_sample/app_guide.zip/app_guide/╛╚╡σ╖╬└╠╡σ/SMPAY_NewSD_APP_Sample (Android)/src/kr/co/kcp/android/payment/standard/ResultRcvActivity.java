package kr.co.kcp.android.payment.standard;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;

public class ResultRcvActivity extends Activity
{

    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        Log.d( SampleApplication.m_strLogTag, "[ResultRcvActivity] called__onCreate" );

        super.onCreate(savedInstanceState);

        Intent myIntent = getIntent();

        Log.d(  SampleApplication.m_strLogTag,
                "[ResultRcvActivity] launch_uri=[" + myIntent.getData().toString() + "]" );

        finish();
    }
}