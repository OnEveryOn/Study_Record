package kr.co.kcp.android.payment.standard;

import android.app.Application;
import android.net.Uri;

public class SampleApplication extends Application
{
    public  Uri     m_uriResult;
    public  boolean b_type      = false;

	public  static final  String  m_strLogTag = "PaySample";
}
