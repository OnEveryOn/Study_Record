package kr.co.kcp.android.payment.standard;

import java.io.UnsupportedEncodingException;
import java.net.URISyntaxException;
import java.net.URLEncoder;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.webkit.CookieManager;
import android.webkit.JsResult;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

public class PayDemoActivity extends Activity
{
    public static final String   ACTIVITY_RESULT         = "ActivityResult";
    public static final int      PROGRESS_STAT_NOT_START = 1;
    public static final int      PROGRESS_STAT_IN        = 2;
    public static final int      PROGRESS_DONE           = 3;
    public static       String   CARD_CD                 = "";
    public static       String   QUOTA                   = "";
    public              WebView  mWebView;
    public              int      m_nStat                 = PROGRESS_STAT_NOT_START;
    private final       String   SCHEME                  = "paysample://card_pay";
    
    /** Called when the activity is first created. */
    @Override
    @SuppressLint( {"NewApi", "SetJavaScriptEnabled"} )
    public void onCreate(Bundle savedInstanceState)
    {
        Log.d( SampleApplication.m_strLogTag, "[PayDemoActivity] called__onCreate" );

        super.onCreate(savedInstanceState);
        setContentView( R.layout.paydemo );

        String url      = "http://www.testkcp.co.kr/kcp_in/dev1_team_kms/smart_phone_linux_jsp/sample/";
        String postData = "";

        if( getIntent().getStringExtra( "urlType" ).equals( "OUT" ) )
        {
            url = "http://testpay.kcp.co.kr/kcp_in/dev1_team_kms/smart_phone_linux_jsp/sample/";
        }
        
        try
        {
            postData = "AppUrl=" + URLEncoder.encode(SCHEME, "EUC-KR");
        }
        catch (UnsupportedEncodingException e)
        {
            e.printStackTrace();
        }
        
        mWebView = (WebView)findViewById( R.id.webview );

        mWebView.getSettings().setJavaScriptEnabled( true );
        mWebView.getSettings().setDomStorageEnabled( true ); // 2017�� �� ����ϼ���(����) ������ ��� �ʼ�.
        
        // ��Ű ó���� �ʼ� (2017�� �� ����ϼ��������� ���� �����̳� ī��� ������ �ʼ�ó�� ��û)
        if ( Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP ) {
            mWebView.getSettings().setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW); 
 
            CookieManager cookieManager = CookieManager.getInstance(); 
            cookieManager.setAcceptCookie(true); 
            cookieManager.setAcceptThirdPartyCookies(mWebView, true); 
        } 
        
        //mWebView.getSettings().setAppCacheEnabled( true ); // ���� ������ KCP
        //mWebView.getSettings().setCacheMode(int); // ��� ���� ���� KCP
        
        mWebView.setWebChromeClient( new mWebChromeClient() );
        mWebView.setWebViewClient  ( new mWebViewClient()  );

        mWebView.postUrl( url, postData.getBytes() );
    }

    private class mWebChromeClient extends WebChromeClient
    {
        @Override
        public boolean onJsAlert( WebView view, String url, String message, JsResult result )
        {
            final JsResult finalRes = result;
            
            AlertDialog.Builder dlgBuilder = new AlertDialog.Builder( view.getContext() );
            AlertDialog alertDlg;

            dlgBuilder.setMessage( message );
            dlgBuilder.setCancelable( false );
            dlgBuilder.setPositiveButton( android.R.string.ok, new DialogInterface.OnClickListener()
            {
                @Override
                public void onClick(DialogInterface dialog, int which)
                {
                    finalRes.confirm();
                }
            });

            alertDlg = dlgBuilder.create();
            alertDlg.show();
            
            return  alertDlg.isShowing();
        }
        
        @Override
        public boolean onJsConfirm( WebView view, String url, String message, final JsResult result )
        {
            AlertDialog.Builder dlgBuilder = new AlertDialog.Builder( view.getContext() );
            AlertDialog alertDlg;

            dlgBuilder.setMessage( message );
            dlgBuilder.setCancelable( false );
            dlgBuilder.setPositiveButton( android.R.string.ok, new DialogInterface.OnClickListener()
            {
                @Override
                public void onClick(DialogInterface dialog, int which)
                {
                    result.confirm();
                }
            });

            dlgBuilder.setNegativeButton( android.R.string.cancel, new DialogInterface.OnClickListener()
            {
                @Override
                public void onClick(DialogInterface dialog, int which)
                {
                    result.cancel();
                }
            });

            alertDlg = dlgBuilder.create();
            alertDlg.show();
            
            return  alertDlg.isShowing();
        }
    }
    
    private boolean url_scheme_intent( WebView view, String url )
    {
        Log.d( SampleApplication.m_strLogTag, "[PayDemoActivity] called__test - url=[" + url + "]" );

        //chrome ���� ��� : 2014.01 �߰�
        if ( url.startsWith( "intent" ) )
        {
            Intent intent = null;
            
            try {
                intent = Intent.parseUri( url, Intent.URI_INTENT_SCHEME );
            } catch ( URISyntaxException ex ) {
                Log.d( SampleApplication.m_strLogTag, "[PayDemoActivity] URISyntaxException=[" + ex.getMessage() + "]" );
                return false;
            }
            
            // �ۼ�ġ üũ�� �մϴ�.
            if ( getPackageManager().resolveActivity( intent, 0 ) == null )
            {
                String packagename = intent.getPackage();
                
                if ( packagename != null )
                {
                    startActivity( new Intent( Intent.ACTION_VIEW, Uri.parse( "market://search?q=pname:" + packagename ) ) );
                    
                    return true;
                }
            }
            
            intent = new Intent( Intent.ACTION_VIEW, Uri.parse( intent.getDataString() ) );
            
            try{
                startActivity( intent );
            }catch( ActivityNotFoundException e ) {
                Log.d( SampleApplication.m_strLogTag, "[PayDemoActivity] ActivityNotFoundException=[" + e.getMessage() + "]" );
                return false;
            }
        }
        // ���� ���
        else
        {
            /*
             * �Ʒ� �ּ��� ������ ��ü���� �ʿ信 ���� �����ϴ� �κ��Դϴ�.
             * KCP������ ������ �����ɼ� �ֵ��� ó���� �Ǿ� �ֽ��ϴ�.
             * ���ÿ��� �Ǵ��� �ʿ��Ұ�� �߰����ּ���.
             * ��. �Ʒ� �ּ� ������ �������� KCP ���� ������ �����մϴ�.
             *
            if ( url.startsWith( "ispmobile" ) )
            {
                if( !new PackageState( this ).getPackageDownloadInstallState( "kvp.jjy.MispAndroid" ) )
                {
                    startActivity( new Intent(Intent.ACTION_VIEW, Uri.parse( "market://details?id=kvp.jjy.MispAndroid320" ) ) );
                    
                    return true;
                }
            }
            
            // �Ｚ�� ���� ��� ������ ���� ��� �������� �̵� �Ҽ� �ֵ��� ���� ���� �Դϴ�.
            // ���� ������ ��ü ���� ���ο� ���� ���� ó�� �Ͻô°��� �����ϴ�.
            if ( url.startsWith( "mpocket.online.ansimclick" ) )
            {
                if( !new PackageState( this ).getPackageDownloadInstallState( "kr.co.samsungcard.mpocket" ) )
                {
                    Toast.makeText(this, "������ ��ġ �� �ٽ� �õ��� �ּ���.", Toast.LENGTH_LONG).show();
                    
                    startActivity( new Intent(Intent.ACTION_VIEW, Uri.parse( "market://details?id=kr.co.samsungcard.mpocket" ) ) );
                    
                    return true;
                }
            }
            */
            
            try
            {
                startActivity( new Intent( Intent.ACTION_VIEW, Uri.parse( url ) ) );
            }
            catch(Exception e)
            {
                // ������ ��ġ �ȵǾ� ������� ���� �߻�. �ش� �κ��� ��ü�� �°� ����
                Toast.makeText(this, "�ش� ������ ��ġ�� �ּ���.", Toast.LENGTH_LONG).show();
            }
        }

        return true;
    }

    private class mWebViewClient extends WebViewClient
    {
        @Override
        public boolean shouldOverrideUrlLoading( WebView view, String url )
        {
            Log.d( SampleApplication.m_strLogTag, "[PayDemoActivity] called__shouldOverrideUrlLoading - url=[" + url + "]" );

            if (url != null && !url.equals("about:blank"))
            {
                if( url.startsWith("http://") || url.startsWith("https://"))
                {
                    if (url.contains("http://market.android.com")            ||
                        url.contains("http://m.ahnlab.com/kr/site/download") ||
                        url.endsWith(".apk")                                   )
                    {
                        return url_scheme_intent( view, url );
                    }
                    else
                    {
                        view.loadUrl( url );
                    }
                }
                else if(url.startsWith("mailto:"))
                {
                    return false;
                }
                else if(url.startsWith("tel:"))
                {
                    return false;
                }
                else
                {
                    return url_scheme_intent( view, url );
                }
            }

            return true;
        }
    }

    @Override
    public void onBackPressed()
    {
        //super.onBackPressed();
        
        Log.d( SampleApplication.m_strLogTag, "[PayDemoActivity] called__onBackPressed" );
    
        AlertDialog.Builder  dlgBuilder = new AlertDialog.Builder( this );
        AlertDialog          alertDlg;
        
        dlgBuilder.setTitle( "���" );
        dlgBuilder.setMessage( "������ �������Դϴ�.\n����Ͻðڽ��ϱ�?" );
        dlgBuilder.setCancelable( false );
        dlgBuilder.setPositiveButton( "��",
                                      new DialogInterface.OnClickListener()
                                            {
                                                @Override
                                                public void onClick(DialogInterface dialog, int which)
                                                {
                                                    dialog.dismiss();
                                                    
                                                    finishActivity( "����� ���" );
                                                }
                                            }
                                     );
        dlgBuilder.setNegativeButton( "�ƴϿ�",
                                      new DialogInterface.OnClickListener()
                                            {
                                                @Override
                                                public void onClick(DialogInterface dialog, int which)
                                                {
                                                    dialog.dismiss();
                                                }
                                            }
                                     );
    
        alertDlg = dlgBuilder.create();
        
        alertDlg.show();
    }
    
    public void finishActivity( String p_strFinishMsg )
    {
        Intent intent = new Intent();

        if ( p_strFinishMsg != null )
        {
            intent.putExtra( ACTIVITY_RESULT, p_strFinishMsg );

            setResult( RESULT_OK, intent );
        }
        else
        {
            setResult( RESULT_CANCELED );
        }

        finish();
    }
}