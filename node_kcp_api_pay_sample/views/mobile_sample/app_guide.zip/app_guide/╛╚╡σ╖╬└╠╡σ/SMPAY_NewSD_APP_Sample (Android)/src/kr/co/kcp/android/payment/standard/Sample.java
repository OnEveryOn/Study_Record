package kr.co.kcp.android.payment.standard;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;

public class Sample extends Activity implements OnClickListener
{
    public               EditText m_edtActivityResult;
    private static final int      ACTIVITY_PAYDEMO    = 1;
    
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        Log.d( SampleApplication.m_strLogTag, "[Sample] event__onCreate" );

        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

        Button button1 = (Button)findViewById( R.id.Button01 );
        Button button2 = (Button)findViewById( R.id.Button02 );
        
        button1.setOnClickListener( this );
        button2.setOnClickListener( this );
        
        m_edtActivityResult = (EditText)findViewById( R.id.edtActivityResult );
    }
    
    public void onClick( View p_view )
    {
        if ( p_view.getId() == R.id.Button01 )
        {
            actionPayDemo( "IN" );
        }
        else if ( p_view.getId() == R.id.Button02 )
        {
            actionPayDemo( "OUT" );
        }
    }
    
    private void actionPayDemo( String type )
    {
        Intent intent = new Intent();
        
        intent.putExtra( "urlType", type );
        intent.setClass( Sample.this, PayDemoActivity.class );
        
        startActivityForResult( intent, ACTIVITY_PAYDEMO );
    }
    
    @Override
    protected void onActivityResult( int     p_requestCode,
                                     int     p_resultCode,
                                     Intent  p_intentActivity )
    {
        if ( p_requestCode == ACTIVITY_PAYDEMO )
        {
            if ( p_resultCode == RESULT_OK )
            {
                m_edtActivityResult.setText( p_intentActivity.getExtras().getString( PayDemoActivity.ACTIVITY_RESULT ) );
            }
            else
            {
                m_edtActivityResult.setText( "��� �˼� ���� (��� �Ǵ� ���� �߻�)" );
            }
        }
        else
        {
            super.onActivityResult( p_requestCode, p_resultCode, p_intentActivity );
        }
    }
}