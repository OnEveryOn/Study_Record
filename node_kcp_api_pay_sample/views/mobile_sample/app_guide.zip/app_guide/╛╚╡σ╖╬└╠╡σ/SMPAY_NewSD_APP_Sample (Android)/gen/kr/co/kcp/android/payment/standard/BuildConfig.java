/** Automatically generated file. DO NOT MODIFY */
package kr.co.kcp.android.payment.standard;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}