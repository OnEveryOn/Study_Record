//
//  SettingViewController.h
//  testKCPCardSample
//
//  Created by kcpmac on 12. 9. 21..
//  Copyright (c) 2012년 kcpmac. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SettingViewController : UIViewController
-(IBAction)check:(id)sender;
@end
