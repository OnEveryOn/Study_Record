//
//  ViewController.h
//  testKCPCardSample
//
//  Created by kcpmac on 12. 9. 20..
//  Copyright (c) 2012년 kcpmac. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <WebKit/WebKit.h>

@interface ViewController : UIViewController<WKUIDelegate , WKNavigationDelegate , WKScriptMessageHandler>
{
    WKWebView  *mainWebView;
}

@property(nonatomic, strong) WKWebView* mainWebView;
@property(nonatomic, strong)IBOutlet UIWebView *webview;

@end