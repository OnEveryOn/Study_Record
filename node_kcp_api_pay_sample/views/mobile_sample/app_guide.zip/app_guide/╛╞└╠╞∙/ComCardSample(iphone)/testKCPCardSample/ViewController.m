//
//  ViewController.m
//  testKCPCardSample
//
//  Created by kcpmac on 12. 9. 20..
//  Copyright (c) 2012년 kcpmac. All rights reserved.
//

#import "ViewController.h"

#import <UIKit/UIKit.h>
#import <WebKit/WebKit.h>

@interface ViewController()<WKNavigationDelegate, WKUIDelegate>
//@property (nonatomic, strong) WKWebView *mainWebView;

@end

@implementation ViewController
{
    // 웹뷰의 랜더 속도 및 각종 설정들을 담당하는 클래스
    WKWebViewConfiguration *config;
    // 자바스크립트에서 메시지를 받거나 자바스크립트를 실행하는데 필요한 클래스
    WKUserContentController *jsctrl;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    config = [[WKWebViewConfiguration alloc]init];
    jsctrl = [[WKUserContentController alloc]init];
    
    // 자바스크립트 -> ios에 사용될 핸들러 이름을 추가
    // 핸들러 및 프로토콜을 ioscall로 통일합
    [jsctrl addScriptMessageHandler:self name:@"openURL"];
    // WkWebView의 configuration에 스크립트에 대한 설정
    [config setUserContentController:jsctrl];
    config.allowsInlineMediaPlayback = YES;
    config.mediaPlaybackAllowsAirPlay = false;
    config.preferences.javaScriptCanOpenWindowsAutomatically = YES;
    
    
    CGRect frame = [[UIScreen mainScreen]bounds];
    mainWebView = [[WKWebView alloc] initWithFrame:frame configuration:config];
    // 웹뷰의 딜리게이트들을 새로 초기화
    [mainWebView setUIDelegate:self];
    [mainWebView setNavigationDelegate:self];
    [mainWebView setAutoresizingMask:UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight];
    
    // WkWebView는 IBOutlet으로 제공되지 않아 스토리보드에서 추가 불가
    // 웹뷰의 크기를 정해준 후 초기화하고 본 ViewController의 뷰에 추가
    [[self view]addSubview:mainWebView];
    
    //테스트
    NSURL *url = [NSURL URLWithString:@"http://testpay.kcp.co.kr/kcp_in/dev1_team_kms/new_smart_phone_linux_jsp/sample/card/order_card.jsp?AppUrl=testKCPCardSample://card_pay?"];
    
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url];
    
    [mainWebView loadRequest:request];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
}

- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType{
    
    return YES;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - WKNavigationDelegate
- (void)webView:(WKWebView *)webView didStartProvisionalNavigation:(null_unspecified WKNavigation *)navigation
{
    
}

- (void)webView:(WKWebView *)webView didCommitNavigation:(null_unspecified WKNavigation *)navigation
{
    
}

- (void)webView:(WKWebView *)webView didFinishNavigation:(null_unspecified WKNavigation *)navigation
{
    
}

- (void)webView:(WKWebView *)webView didFailNavigation:(null_unspecified WKNavigation *)navigation withError:(NSError *)erro
{
    
}

- (void)webView:(WKWebView *)webView decidePolicyForNavigationAction:(WKNavigationAction *)navigationAction decisionHandler:(void (^)(WKNavigationActionPolicy))decisionHandler
{
    NSURL *url = navigationAction.request.URL;
    NSString* strURL = [url absoluteString];
    
    if([strURL rangeOfString:@"//itunes.apple.com/"].location != NSNotFound)
    {
        [[UIApplication sharedApplication] openURL:url];
        decisionHandler(WKNavigationResponsePolicyCancel);
        return;
        
    }
    else if(![strURL hasPrefix:@"http://"] && ![strURL hasPrefix:@"https://"])
    {
        if([[UIApplication sharedApplication] canOpenURL:url])
        {
            [[UIApplication sharedApplication] openURL:url];
            decisionHandler(WKNavigationResponsePolicyCancel);
            return;
        }
    }
    
    switch(navigationAction.navigationType)
    {
        case WKNavigationTypeLinkActivated:
            if(!navigationAction.targetFrame || !navigationAction.targetFrame.isMainFrame)
            {
                [mainWebView loadRequest:strURL];
                return;
            }
        case WKNavigationTypeBackForward:
            break;
        case WKNavigationTypeFormResubmitted:
            break;
        case WKNavigationTypeFormSubmitted:
            break;
        case WKNavigationTypeOther:
            break;
        case WKNavigationTypeReload:
            break;
    }
    
    decisionHandler(WKNavigationResponsePolicyAllow);
}

#pragma mark - delegate method

// WKScriptMessageHandler에 의해 생성된 delegate 함수
// 자바스크립트에서 ios에 wekkit핸들러를 통해 postMessage함수를 사용한 경우 실행
// 이부분은 자바스크립트와 WKWebView 간에 통신이 필요할 때 사용
- (void)userContentController:(WKUserContentController *)userContentController
      didReceiveScriptMessage:(WKScriptMessage *)message
{
    //웹에서 window.webkit.messageHandlers.openURL.posstMessage("test");
    
    /*if ([message.body[@"callbackName"] isEqual: @"openURLcallbackScriptName"])
    {
        [mainWebView evaluateJavaScript:[NSString stringWithFormat:@"openURLcallbackScriptName('%s');","false"] completionHandler:^(NSString *result, NSError *error)
         {
             
         }];
    }
    
    if ([message.body[@"result"] isEqual: @"success"])
    {
        UIAlertView* alertModal1;
        alertModal1 = [[UIAlertView alloc]initWithTitle:@"호출"message:message.body[@"result"] delegate:nil cancelButtonTitle:@"결과" otherButtonTitles:nil];
        [alertModal1 show];
    }
    
    if ([message.body[@"result"] isEqual: @"fail"])
    {
        UIAlertView* alertModal2;
        alertModal2 = [[UIAlertView alloc]initWithTitle:@"호출"message:message.body[@"result"] delegate:nil cancelButtonTitle:@"결과" otherButtonTitles:nil];
        [alertModal2 show];
    }*/
}


@end